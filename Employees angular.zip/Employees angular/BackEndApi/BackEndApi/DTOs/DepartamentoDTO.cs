﻿namespace BackEndApi.DTOs
{
    public class DepartamentoDTO
    {
        public int IdDepartamento { get; set; }

        public string? Nombre { get; set; }
    }
}
