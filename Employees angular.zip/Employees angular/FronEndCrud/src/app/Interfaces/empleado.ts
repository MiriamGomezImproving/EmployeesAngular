export interface Empleado {
    idEmpleado : number, 
    nombreCompleto : string, 
    idDepartamento : number, 
    nombreDepartamento? : string, 
    sueldo: number, 
    fechaContrato : string 
}
