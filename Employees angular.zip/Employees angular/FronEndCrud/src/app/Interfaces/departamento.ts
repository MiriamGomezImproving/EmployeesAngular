export interface Departamento {
    idDepartamento :number, 
    nombre :string
}
